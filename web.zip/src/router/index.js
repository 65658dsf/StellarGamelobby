import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../store/auth'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      component: () => import('../components/LoginForm.vue'),
      meta: { requiresAuth: false }
    },
    {
      path: '/lobby',
      component: () => import('../components/GameLobby.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/',
      redirect: '/login'
    }
  ]
})

router.beforeEach(async (to, from, next) => {
  // 使用已经在 main.js 中初始化的 pinia store
  const authStore = useAuthStore()
  
  // 如果页面需要认证
  if (to.meta.requiresAuth) {
    // 如果用户未登录，先尝试自动登录
    if (!authStore.isAuthenticated) {
      const isAutoLoginSuccessful = await authStore.autoLogin()
      
      if (!isAutoLoginSuccessful) {
        // 如果自动登录失败，重定向到登录页
        return next({
          path: '/login',
          query: { redirect: to.fullPath }
        })
      }
    }
  }
  
  // 如果用户已登录且试图访问登录页，重定向到大厅
  if (to.path === '/login' && authStore.isAuthenticated) {
    return next('/lobby')
  }
  
  next()
})

export default router 