<template>
  <n-form
    ref="formRef"
    :model="formValue"
    :rules="rules"
  >
    <n-form-item label="房间名称" path="roomName">
      <n-input v-model:value="formValue.roomName" placeholder="给您的游戏房间起个名字">
        <template #prefix>
          <n-icon><game-controller /></n-icon>
        </template>
      </n-input>
    </n-form-item>
    
    <n-form-item label="游戏名称" path="gameName">
      <n-input v-model:value="formValue.gameName" placeholder="您正在运行的游戏名称（选填）">
        <template #prefix>
          <n-icon><game-controller /></n-icon>
        </template>
      </n-input>
    </n-form-item>

    <n-form-item label="房间描述" path="description">
      <n-input
        v-model:value="formValue.description"
        type="textarea"
        placeholder="请输入房间描述（选填）"
        :autosize="{ minRows: 2, maxRows: 4 }"
      />
    </n-form-item>

    <n-form-item label="联机IP" path="serverIp">
      <n-input v-model:value="formValue.serverIp" placeholder="游戏服务器IP地址（选填）">
        <template #prefix>
          <n-icon><server-outline /></n-icon>
        </template>
      </n-input>
    </n-form-item>

    <n-form-item label="客户端下载地址" path="downloadUrl">
      <n-input 
        v-model:value="formValue.downloadUrl" 
        placeholder="游戏客户端下载地址（选填，需要是完整的 URL）"
      >
        <template #prefix>
          <n-icon><download-outline /></n-icon>
        </template>
      </n-input>
    </n-form-item>
    
    <n-form-item label="房间类型" required>
      <n-radio-group v-model:value="formValue.isPrivate">
        <n-space>
          <n-radio :value="false">公开房间</n-radio>
          <n-radio :value="true">私密房间</n-radio>
        </n-space>
      </n-radio-group>
    </n-form-item>
    
    <n-form-item 
      v-if="formValue.isPrivate" 
      label="房间密码" 
      path="password"
    >
      <n-input
        v-model:value="formValue.password"
        type="password"
        show-password-on="click"
        placeholder="请设置房间密码"
      >
        <template #prefix>
          <n-icon><lock-closed /></n-icon>
        </template>
      </n-input>
    </n-form-item>
    
    <n-button type="primary" block @click="handleCreateRoom" :loading="loading">
      <template #icon>
        <n-icon><add-circle /></n-icon>
      </template>
      创建房间
    </n-button>
  </n-form>
</template>

<script setup>
import { ref } from 'vue'
import { useMessage } from 'naive-ui'
import { 
  NForm, 
  NFormItem, 
  NInput, 
  NButton,
  NIcon,
  NRadio,
  NRadioGroup,
  NSpace
} from 'naive-ui'
import { 
  GameController,
  LockClosed,
  AddCircle,
  ServerOutline,
  DownloadOutline
} from '@vicons/ionicons5'
import { useLobbyStore } from '../store/lobby'
import { useAuthStore } from '../store/auth'

const store = useLobbyStore()
const authStore = useAuthStore()
const message = useMessage()
const formRef = ref(null)
const loading = ref(false)

const formValue = ref({
  roomName: '',
  gameName: '',
  description: '',
  serverIp: '',
  downloadUrl: '',
  isPrivate: false,
  password: ''
})

const rules = {
  roomName: { 
    required: true, 
    message: '请输入房间名称',
    trigger: ['blur', 'input'],
    validator: (rule, value) => {
      if (!value) {
        return new Error('请输入房间名称')
      }
      if (value.length > 50) {
        return new Error('房间名称不能超过50个字符')
      }
      return true
    }
  },
  serverIp: { 
    trigger: ['blur', 'input'],
    validator: (rule, value) => {
      if (!value) return true
      const ipPattern = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/
      if (!ipPattern.test(value)) {
        return new Error('请输入正确的IP地址格式')
      }
      return true
    }
  },
  password: {
    required: true,
    message: '请输入房间密码',
    trigger: ['blur', 'input'],
    validator: (rule, value) => {
      if (formValue.value.isPrivate && !value) {
        return new Error('私密房间需要设置密码')
      }
      if (formValue.value.isPrivate && value.length < 4) {
        return new Error('密码长度至少4位')
      }
      return true
    }
  },
  downloadUrl: {
    trigger: ['blur', 'input'],
    validator: (rule, value) => {
      if (!value) return true // 允许为空
      
      try {
        const url = new URL(value)
        return url.protocol === 'http:' || url.protocol === 'https:'
          ? true
          : new Error('请输入有效的 http 或 https URL')
      } catch (e) {
        return new Error('请输入有效的完整 URL，例如: https://example.com/download')
      }
    }
  }
}

const handleCreateRoom = async () => {
  try {
    loading.value = true
    await formRef.value?.validate()
    
    const roomData = {
      roomName: formValue.value.roomName,
      gameName: formValue.value.gameName || '未指定',
      description: formValue.value.description,
      serverIp: formValue.value.serverIp,
      downloadUrl: formValue.value.downloadUrl,
      isPrivate: formValue.value.isPrivate,
      password: formValue.value.isPrivate ? formValue.value.password : null,
      hostId: authStore.user.id,
      hostName: authStore.user.username
    }
    
    await store.createRoom(roomData)
    message.success('房间创建成功')
    
    // 重置表单
    formValue.value = {
      roomName: '',
      gameName: '',
      description: '',
      serverIp: '',
      downloadUrl: '',
      isPrivate: false,
      password: ''
    }
  } catch (error) {
    message.error(error.message || '创建房间失败，请检查输入并重试')
  } finally {
    loading.value = false
  }
}
</script> 